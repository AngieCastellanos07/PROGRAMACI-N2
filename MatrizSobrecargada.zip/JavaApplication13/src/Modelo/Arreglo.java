
package Modelo;

import javax.swing.JOptionPane;

public class Arreglo{
    public int M[][] = new int[3][3];

    
    
    public Arreglo(){
        for(int x=0; x < M.length; x++) {
            for (int y=0; y < M[x].length; y++) {
                M[x][y] = (int) (Math.random()*99+1);
            }
        }
    }
    
    
    public Arreglo(int a) {
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                M[i][j] = Integer.parseInt(JOptionPane.showInputDialog("Posicion [" + i + "" + j + "]:"));
            }
        }
    }

    public Arreglo(Arreglo a,Arreglo b){
        
        int x[][]  = a.M;
        int y[][] = b.M;
        for(int k = 0; k < y[0].length; k++) {           
            for (int i = 0; i < x.length; i++) {
                int suma = 0;               
                for (int j = 0; j < x[0].length; j++) {                  
                    suma += x[i][j] * y[j][k];
                }               
                M[i][k] = suma;
            }
        }
    }
    
    public void Imprimir() {
        String salida = "los datos del arreglo son:\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                salida += " | " + M[i][j] + " | " + " ";
            } 
            salida += "\n";
        }
        JOptionPane.showMessageDialog(null, salida);
    }
}

