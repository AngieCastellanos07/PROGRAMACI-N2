
 
package Matriz;

import Modelo.Arreglo;
import javax.swing.JOptionPane;

public class Vista {

    public static void main(String[] args) {
        Arreglo  ob1=null, ob2=null, ob3=null ;
        int op;
        do {
            op = Integer.parseInt(JOptionPane.showInputDialog("MENU PRINCIPAL\n 1. CARGAR\n 2. IMPRIMIR\n 3. SALIR"));
            switch(op){
                case 1:
                    do{
                        op = Integer.parseInt(JOptionPane.showInputDialog("MENU CARGAR\n 1. aleatorio\n 2. teclado\n 3.multiplicaar\n 4.volver"));
                        switch(op){
                            case 1:
                                ob1 = new Arreglo();
                                break;
                            case 2:
                                ob2 = new Arreglo(1);
                                break;
                            case 3:
                                ob3 = new Arreglo(ob1,ob2);
                                break;
                            
                        }
                
                
                    }while (op != 4);
                    break;
                case 2: 
                    do{
                        op = Integer.parseInt(JOptionPane.showInputDialog("MENU IMPRIMIR\n 1. datos ob1\n 2. datos ob2\n 3. datos ob3 \n 4. volver"));
                        switch(op){
                            case 1:
                                ob1.Imprimir();
                                break;
                            case 2:
                                ob2.Imprimir();
                                break;
                            case 3:
                                ob3.Imprimir();
                                break;
                                
                        }
                
                
                    }while (op != 4);
                    break;
                   
            }
        } while (op != 3);

    }

}
