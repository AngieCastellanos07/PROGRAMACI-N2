
package MisClases;
import javax.swing.JOptionPane;
public class Arreglo{
	int M[]=new int[5];
	public void cargar(){
		for(int i=0;i<5;i++){
		    M[i]=Integer.parseInt(JOptionPane.showInputDialog("Posicion ["+i+"]:"));
		}
	}
	public void impri(){
		String salida="los datos del arreglo son:\n";
		for(int i=0;i<5;i++){
		    salida=salida+" | "+M[i]+" | "+" ";
		}
		JOptionPane.showMessageDialog(null,salida);
	}
	public void Invertir() {
		
		int filas = M.length;
       		int temporal[] = new int[filas];
        	int contador = 0;
        	for (int i = filas - 1, x = 0; x < M.length; i--, x++) {      
                	temporal[contador++] = M[i];  
        	}
        	contador = 0;
        	for (int i = 0; i < filas; i++) {   
                	M[i] = temporal[contador++];    
        	} 
        }
	public void Ordenar(){
		int op;
		op=Integer.parseInt(JOptionPane.showInputDialog("        ***Menu Ordenar****\n1. Burbuja\n2. Secuanecial\ndigite opcion"));
		if(op == 1){
			for (int i = 0; i < 5; i++) {
          			for (int j = 0; j < 5; j++) {              
                    			if (M[i] < M[j]) {
                            			int t = M[i];
                            			M[i] = M[j];
                            			M[j] = t;
                    			}
					
            			}
                     
        		}
		JOptionPane.showMessageDialog(null,"Arreglo ordenado de forma Acendente!");
       
 		}
	
		else if(op == 2){
			for (int i = 0; i < 5; i++) {
          			for (int j = 0; j < 5; j++) {              
                    			if (M[i] > M[j]) {
                            			int t = M[i];
                            			M[i] = M[j];
                            			M[j] = t;
                    			}
					
            			}
                     
        		}
       		JOptionPane.showMessageDialog(null,"Arreglo ordenado de forma Descendente!");

		}
		else{
			JOptionPane.showMessageDialog(null,"opccion incorecta");	
		}
	}
       	

}
	




